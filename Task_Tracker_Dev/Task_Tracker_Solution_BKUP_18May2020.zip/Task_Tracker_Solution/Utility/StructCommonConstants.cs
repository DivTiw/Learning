﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Task_Tracker_Solution.Utility
{
    public static class SessionNames
    {
        public const string empSyscode = "";
    }
}