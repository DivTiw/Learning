﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Task_Tracker_CommonLibrary.DomainModels;

namespace Task_Tracker_Solution.Areas.Tasks.Models
{
    public class TaskViewModel : TaskDM
    {
        public SelectList SLPriority { get; set; }
        public SelectList SLStatus { get; set; }
        public SelectList SLDeptUsers { get; set; }    

        public SelectList SLCategory{ get; set; }

        public SelectList SLdepartment { get; set; }

      

    }
}