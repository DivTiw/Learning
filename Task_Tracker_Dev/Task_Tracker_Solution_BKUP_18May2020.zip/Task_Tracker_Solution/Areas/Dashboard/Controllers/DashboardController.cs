﻿using Common_Components;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_Solution.Areas.Common.Controllers;
using Task_Tracker_Solution.Utility;

namespace Task_Tracker_Solution.Areas.Dashboard.Controllers
{
    public class DashboardController : TaskTrackerBaseController
    {
        // GET: Dashboard/Dashboard
        public ActionResult MyTaskActivity()
        {
            IList<TaskDM> viewmodel = null;
            try
            {
                string sreturn = string.Empty;

                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

                    TaskUserMapping taskUser = new TaskUserMapping();
                    taskUser.employee_syscode = loggedin_user;

                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetMyTaskActivity, taskUser).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        viewmodel = JsonConvert.DeserializeObject<IList<TaskDM>>(responseMsg);
                    }
                    else
                    {
                        throw new Exception(response.ReasonPhrase);
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                ViewBag.ErrorMessage = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "MyTasks", "TaskController");
            }

            return View(viewmodel);
        }

        public ActionResult OpenTasks()
        {           
            IList<TaskDM> viewmodel = null;
            try
            {
                string sreturn = string.Empty;
               
                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

                    TaskUserMapping taskUser = new TaskUserMapping();
                    taskUser.employee_syscode = loggedin_user;

                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetTodaysLatestTasks, taskUser).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        viewmodel = JsonConvert.DeserializeObject<IList<TaskDM>>(responseMsg);
                    }
                    else
                    {
                        throw new Exception(response.ReasonPhrase);
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = ""});
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                ViewBag.ErrorMessage = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "MyTasks", "TaskController");
            }

            return View(viewmodel);
        }


        public ActionResult GetAdminDashboard(DashBoard taskuser)
        {
            DashBoard viewmodel = null;

            try
            {
                string sreturn = string.Empty;

                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
                    // loggedin_user = 3986;
                    taskuser.ed_syscode = loggedin_user;
                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetDashboard, taskuser).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        viewmodel = JsonConvert.DeserializeObject<DashBoard>(responseMsg);
                    }
                    else
                    {
                        throw new Exception(response.ReasonPhrase);
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                ViewBag.ErrorMessage = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "MyTasks", "TaskController");
            }

            return View("Dashboard",viewmodel);
        }

       //[HttpPost]
       //public ActionResult GetfilteredData(DateTime? startdate, DateTime? enddate)
       // {
       //     DashBoard viewmodel = null;
       //     try
       //     {
       //         string sreturn = string.Empty;

       //         if (this.Session["emp_syscode"] != null)
       //         {
       //             int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
       //             // loggedin_user = 3986;

       //             TaskUserMapping taskUser = new TaskUserMapping();
       //             taskUser.employee_syscode = loggedin_user;

       //             var response = client.PostAsJsonAsync(cWebApiNames.APIGetDashboard, taskUser).Result;
       //             var responseMsg = response.Content.ReadAsStringAsync().Result;
       //             if (response.IsSuccessStatusCode)
       //             {
       //                 viewmodel = JsonConvert.DeserializeObject<DashBoard>(responseMsg);
       //                 viewmodel = JsonConvert.DeserializeObject<DashBoard>(responseMsg);
       //                 if(viewmodel != null)
       //                 {
       //                     var data = viewmodel.lstUsersProjects.FindAll(a=> a.)
       //                     viewmodel.lstUsersProjects.Select
       //                 }
       //             }
       //             else
       //             {
       //                 throw new Exception(response.ReasonPhrase);
       //             }
       //         }
       //         else
       //         {
       //             return RedirectToAction("Logout", "Login", new { Area = "" });
       //         }
       //     }
       //     catch (Exception ex)
       //     {
       //         TempData["ErrorMessage"] = ex.Message;
       //         ViewBag.ErrorMessage = ex.Message;
       //         ModelState.AddModelError("KeyException", ex.Message);
       //         Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "MyTasks", "TaskController");
       //     }

       //     return View("Dashboard", viewmodel);
       // } 

    }
}