﻿/*
    Workflow Levels Json sample
    {
	"Workflow_Levels": {
		"row_Id": "1",
		"workflow_syscode": "1",
		"level_syscode": "1",
		"level_name": "Requirement Gathering",
		"level_order": "1",
		"created_by": "1",
		"created_on": "06-Jan-2019",
		"modified_by": "",
		"modified_on": "",
		"is_active": "1",
		"is_deleted": "0"
	}
}
*/

$(document).ready(function(){
    
    AlertFunc();
});

function AlertFunc(){
    Alert("Alterting when the documet is loaded successfully!");
}