﻿using Common_Components;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Mvc;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_CommonLibrary.Others;
using Task_Tracker_CommonLibrary.Utility;
using Task_Tracker_Solution.Areas.Common.Controllers;
using Task_Tracker_Solution.Areas.Master.Models;
using Task_Tracker_Solution.Utility;

namespace Task_Tracker_Solution.Areas.Master.Controllers
{
    public class ProjectController : TaskTrackerBaseController
    {
        // GET: Master/Project

        public ProjectController()
        {            
        }

        public ActionResult Index()
        {
            return View();
        }


        public ActionResult CreateProject()
        {
            ProjectViewModel projmodel = null;
            try
            {
                ViewBag.Title = "Create Project";
                string sreturn = string.Empty;
                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

                    projmodel = new ProjectViewModel();
                    //projmodel.ddlData.shouldGetData = true;
                    DDLDTO ddldata = projmodel.ddlData;

                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetDDLData, ddldata).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        projmodel.ddlData = JsonConvert.DeserializeObject<DDLDTO>(responseMsg);
                        if (projmodel.ddlData.opStatus)
                        {
                            projmodel.SLWorkFlow = projmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.WorkflowMaster);
                            projmodel.WorkflowListJson = JsonConvert.SerializeObject(projmodel.SLWorkFlow);
                        }
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login");
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Submit", "WorkflowController");
            }

            return View(projmodel);
        }

        public ActionResult EditProject(string id = null)
        {
            ProjectViewModel projmodel = new ProjectViewModel();
            try
            {
                ViewBag.Title = "Edit Project";
                string sreturn = string.Empty;
                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
                    int proj_syscode = String.IsNullOrEmpty(id) ? 0 : Convert.ToInt32(ComLibCommon.Base64Decode(id));

                    if (proj_syscode > 0) //Edit Project
                    {
                        projmodel = new ProjectViewModel();
                        projmodel.project_syscode = proj_syscode;
                        //projmodel.ddlData.shouldGetData = true;

                        var response = client.PostAsJsonAsync(cWebApiNames.APIGetProjectByID, projmodel).Result;
                        var responseMsg = response.Content.ReadAsStringAsync().Result;
                        if (response.IsSuccessStatusCode)
                        {
                            projmodel = JsonConvert.DeserializeObject<ProjectViewModel>(responseMsg);
                            if (projmodel.opStatus)
                            {
                                projmodel.ModulesListJson = JsonConvert.SerializeObject(projmodel.lstModules);                                
                                projmodel.SLWorkFlow = projmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.WorkflowMaster);//[DBTableNameEnums.WorkflowMaster];   
                                projmodel.SLWorkFlow.Insert(0, new SelectItemDTO() { Text = "Select Workflow", Value = "0" });
                                projmodel.WorkflowListJson = JsonConvert.SerializeObject(projmodel.SLWorkFlow);
                               
                            }
                        }
                        else
                        {
                            throw new Exception(response.ReasonPhrase);
                        }
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = ""});
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Submit", "WorkflowController");
            }

            return View("CreateProject", projmodel);
        }

        public ActionResult MyProjects()
        {
            IList<ProjectViewModel> projmodel = null;
            try
            {
                string sreturn = string.Empty;
                if (this.Session["emp_syscode"] != null)
                {
                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetAllProjectList, projmodel).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        projmodel = JsonConvert.DeserializeObject<IList<ProjectViewModel>>(responseMsg);
                    }
                    else
                    {
                        throw new Exception(responseMsg);
                    }
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                }
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Submit", "WorkflowController");
            }

            return View(projmodel);

        }

        [HttpPost]
        public async Task<ActionResult> Submit(ProjectViewModel projmodel, string action)
        {
            try
            {
                string sreturn = string.Empty;
                if (this.Session["emp_syscode"] != null)
                {
                    var response = new HttpResponseMessage();
                    int emp_syscode = int.Parse(Session["emp_syscode"].ToString());
                    projmodel.created_by = emp_syscode;


                    if (!string.IsNullOrEmpty(projmodel.ModulesListJson))
                    {
                        projmodel.lstModules = JsonConvert.DeserializeObject<IList<ModuleMaster>>(projmodel.ModulesListJson);
                        //projmodel.SLWorkFlow = JsonConvert.DeserializeObject<List<SelectItemDTO>>(projmodel.WorkflowListJson);
                    }
                    if (!string.IsNullOrEmpty(projmodel.WorkflowListJson))
                    {                       
                        projmodel.SLWorkFlow = JsonConvert.DeserializeObject<List<SelectItemDTO>>(projmodel.WorkflowListJson);
                        projmodel.SLWorkFlow.Insert(0, new SelectItemDTO() { Text = "Select Workflow", Value = "0" });
                    }
                    #region "Save Project"

                    if (action == "save_project")
                    {
                        if (string.IsNullOrEmpty(projmodel.project_name))
                        {
                            throw new Exception("Please enter Project Name");
                        }
                        if (projmodel.project_syscode > 0)
                        {
                            response = await client.PutAsJsonAsync(Utility.cWebApiNames.APIUpdateProject, projmodel);
                        }
                        else
                        {
                            projmodel.lstModules = null; //During first time project creation, list modules is always null.
                            response = await client.PostAsJsonAsync(Utility.cWebApiNames.APIPostProject, projmodel);
                        }

                        if (response.IsSuccessStatusCode)
                        {
                            var Response = response.Content.ReadAsStringAsync().Result;

                            OperationDetailsDTO od = JsonConvert.DeserializeObject<OperationDetailsDTO>(Response);

                            if (od.opStatus)
                            {
                                ProjectViewModel pvm = JsonConvert.DeserializeObject<ProjectViewModel>(Response);
                                ModelState.Clear();
                                projmodel.project_syscode = pvm.project_syscode;
                                projmodel.opMsg = pvm.opMsg;
                                //projmodel.ModulesListJson = JsonConvert.SerializeObject(projmodel.lstModules);
                                
                                ViewBag.SuccessMessage = projmodel.opMsg;
                                
                                ViewBag.Title = "Edit Project";
                                return View("CreateProject", projmodel);//return RedirectToAction("EditProject", new { id = ComLibCommon.Base64Encode(projmodel.project_syscode + "")});//+"")
                            }
                            else
                            {
                                ViewBag.SuccessMessage = od.opMsg;
                                throw new Exception(od.opMsg, od.opInnerException);
                            }
                        }
                        else
                        {
                            throw new Exception(response.ReasonPhrase);
                        }
                    }
                    #endregion
                    #region "Save Project Modules"
                    else
                    {
                        if (projmodel.lstModules.Count > 0)
                        {
                            if (projmodel.lstModules.Any(m => m.workflow_syscode == 0 || string.IsNullOrEmpty(m.module_name)))
                            {
                                throw new Exception("Please check if you have entered the module name and selected a workflow.");
                            }
                            if (projmodel.lstModules.Any(x=> projmodel.lstModules.Count(y=> y.module_name == x.module_name) > 1)) //Join(projmodel.lstModules, mod=> mod.module_name, modCpy=> modCpy.module_name, (mod, modCpy)=> mod.module_name).Any()
                            {
                                throw new Exception("Please enter unique module names in the list.");
                            }
                            response = await client.PostAsJsonAsync(Utility.cWebApiNames.APIAddUpdateProjectModules, projmodel.lstModules);
                            if (response.IsSuccessStatusCode)
                            {
                                var Response = response.Content.ReadAsStringAsync().Result;
                                ProjectMaster pm = JsonConvert.DeserializeObject<ProjectMaster>(Response);
                                if (pm.opStatus)
                                {
                                    projmodel.lstModules = pm.lstModules;
                                    projmodel.ModulesListJson = JsonConvert.SerializeObject(projmodel.lstModules);
                                    ViewBag.SuccessMessage = pm.opMsg;//"Record saved successfully.";
                                    //TempData.Add("SuccessMessage", "Record saved successfully!");
                                    //TempData.Keep("SuccessMessage");

                                    ViewBag.Title = "Edit Project";
                                    return View("CreateProject", projmodel);//return RedirectToAction("EditProject", new { id = ComLibCommon.Base64Encode(projmodel.project_syscode + "") });
                                }
                                else
                                {
                                    ViewBag.ErrorMessage = "Error occurred while saving the record.";
                                    throw new Exception(pm.opMsg);
                                }
                            }
                            else
                            {
                                throw new Exception(response.ReasonPhrase);
                            }
                        }
                        else
                        {
                            ViewBag.SuccessMessage = "Please add aleast one module for saving.";
                            return View("CreateProject", projmodel);
                        }
                    }
                    #endregion
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Submit", "WorkflowController");
                return View("CreateProject", projmodel);
            }            
        }
    }
}