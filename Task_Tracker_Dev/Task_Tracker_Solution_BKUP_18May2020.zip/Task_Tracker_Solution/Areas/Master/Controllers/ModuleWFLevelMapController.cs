﻿using Common_Components;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http;
using System.Web.Mvc;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_CommonLibrary.Others;
using Task_Tracker_CommonLibrary.Utility;
using Task_Tracker_Solution.Areas.Common.Controllers;
using Task_Tracker_Solution.Areas.Master.Models;
using Task_Tracker_Solution.Utility;

namespace Task_Tracker_Solution.Areas.Master.Controllers
{
    public class ModuleWFLevelMapController : TaskTrackerBaseController
    {
        public ModuleWFLevelMapController()
        {

        }
        // GET: Master/ModuleWFLevelMap
        public ActionResult Index()
        {
          
            ModuleWFLevelMapViewModel viewmodel = null;
            try
            {
                string sreturn = string.Empty;
                if (this.Session["emp_syscode"] != null)
                {
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

                    viewmodel = new ModuleWFLevelMapViewModel();
                    //viewmodel.ddlData.shouldGetData = true;
                    viewmodel.ddlData.Predicate[DBTableNameEnums.ProjectMaster]["GetData"] = true;
                    DDLDTO ddldata = viewmodel.ddlData;

                    var response = client.PostAsJsonAsync(cWebApiNames.APIGetDDLData, ddldata).Result;
                    var responseMsg = response.Content.ReadAsStringAsync().Result;
                    if (response.IsSuccessStatusCode)
                    {
                        viewmodel.ddlData = JsonConvert.DeserializeObject<DDLDTO>(responseMsg);
                        if (viewmodel.ddlData.opStatus)
                        {
                            viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", 0);
                        }
                    }
                    else
                        throw new Exception(response.ReasonPhrase);
                }
                else
                {
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Index", "ModuleWFLevelMapController");
            }
            return View("ModuleWFLevelMap", viewmodel);
        }



        [HttpPost]
        public ActionResult Index(ModuleWFLevelMapViewModel viewmodel, string Action)
        {
            try
            {

                if (this.Session["emp_syscode"] != null)
                {
                    string sreturn = string.Empty;
                    int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

                    if (viewmodel == null)
                        throw new ArgumentNullException("viewmodel", "Model cannot be null.");

                    if (viewmodel.project_syscode <= 0)
                    {
                        ViewBag.ErrorMessage = "Please select the project first";
                        TempData["ErrorMessage"] = "Please select the project first";
                        ModelState.AddModelError("KeyException", "Please select the project first");
                        return RedirectToAction("Index");
                    }

                    string predcName = nameof(viewmodel.project_syscode);
                    //string deptPredcName = nameof(vw_employee_master.department_name);
                    //var deptPredcValue = "Information Technology";

                    int project_syscode = viewmodel.project_syscode;
                    int module_syscode = viewmodel.module_syscode;

                    //viewmodel.ddlData.shouldGetData = true;
                    viewmodel.ddlData.Predicate[DBTableNameEnums.ProjectMaster]["GetData"] = true;
                    viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster]["GetData"] = true;
                    viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster].Add(predcName, project_syscode);


                    if (Action == "Index")
                    {                     

                        if (viewmodel.module_syscode == 0) //Load Projects
                        {
                            var response = client.PostAsJsonAsync(cWebApiNames.APIGetDDLData, viewmodel.ddlData).Result;
                            var responseMsg = response.Content.ReadAsStringAsync().Result;
                            if (response.IsSuccessStatusCode)
                            {
                                viewmodel.ddlData = JsonConvert.DeserializeObject<DDLDTO>(responseMsg);
                                viewmodel.lstLevelTaskUsers = null;
                                if (viewmodel.ddlData.opStatus)
                                {
                                    viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", project_syscode);
                                    viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", 0);
                                }
                            }
                            else
                                throw new Exception(response.ReasonPhrase);
                        }
                        else //Load Modules DD
                        {
                            //ModelState.Clear();
                            viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master]["GetData"] = true;
                            //viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master].Add(deptPredcName, deptPredcValue);

                            var response = client.PostAsJsonAsync(cWebApiNames.GetLevelTaskUsersList, viewmodel).Result;
                            var responseMsg = response.Content.ReadAsStringAsync().Result;
                            if (response.IsSuccessStatusCode)
                            {
                                viewmodel = JsonConvert.DeserializeObject<ModuleWFLevelMapViewModel>(responseMsg);
                                viewmodel.project_syscode = project_syscode;
                                viewmodel.module_syscode = module_syscode;
                                if (viewmodel.opStatus)
                                {
                                    viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", project_syscode);
                                    viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", module_syscode);
                                    viewmodel.SLEmployee = new MultiSelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.vw_employee_master), "Value", "Text");
                                }
                            }
                            else
                                throw new Exception(response.ReasonPhrase);
                        }
                    }
                    else if (Action == "Save")
                    {

                        viewmodel.created_by = loggedin_user;
                        viewmodel.created_by_name = this.Session["emp_name"].ToString();
                        viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master]["GetData"] = true;
                        //viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master].Add(deptPredcName, deptPredcValue);

                     
                        var response = client.PostAsJsonAsync(cWebApiNames.APIAddWFLevelMapping, viewmodel).Result;
                        var responseMsg = response.Content.ReadAsStringAsync().Result;
                        if (response.IsSuccessStatusCode)
                        {
                            viewmodel = JsonConvert.DeserializeObject<ModuleWFLevelMapViewModel>(responseMsg);
                            if (viewmodel.opStatus)
                            {
                                viewmodel.project_syscode = project_syscode;
                                viewmodel.module_syscode = module_syscode;

                                viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", project_syscode);
                                viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", module_syscode);
                                viewmodel.SLEmployee = new MultiSelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.vw_employee_master), "Value", "Text");

                                ViewBag.SuccessMessage = "Record saved sucessfully.";
                                //TempData["SuccessMessage"] = "Record saved sucessfully.";
                                //return Index(viewmodel, "Index");
                            }
                            else
                                throw new Exception(viewmodel.opMsg);
                        }
                        else
                            throw new Exception(response.ReasonPhrase);
                    }
                }
                else
                    return RedirectToAction("Logout", "Login", new { Area = "" });
                ModelState.Clear();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = ex.Message;
                TempData["ErrorMessage"] = ex.Message;
                ModelState.AddModelError("KeyException", ex.Message);
                Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "GetModules", "ModuleWFLevelMapController");
            }            
            return View("ModuleWFLevelMap", viewmodel);
        }



        #region "Commented Code"
        //public ActionResult GetDDData(string projectid, string moduleid)
        //{
        //    ModuleWFLevelMapViewModel viewmodel = null;

        //    int project_syscode = String.IsNullOrEmpty(projectid) ? 0 : Convert.ToInt32(ComLibCommon.Base64Decode(projectid)); //ComLibCommon.Base64Decode(id)
        //    int module_syscode = String.IsNullOrEmpty(moduleid) ? 0 : Convert.ToInt32(ComLibCommon.Base64Decode(moduleid)); //ComLibCommon.Base64Decode(id)

        //    if (project_syscode <= 0)
        //    {
        //        ViewBag.ErrorMessage = "Please select the project first";
        //        TempData["ErrorMessage"] = "Please select the project first";
        //        ModelState.AddModelError("KeyException", "Please select the project first");
        //        return RedirectToAction("Index");//View("ModuleWFLevelMap", viewmodel);
        //    }

        //    try
        //    {
        //        //string sreturn = string.Empty;
        //        if (this.Session["emp_syscode"] != null)
        //        {
        //            int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));

        //            viewmodel = new ModuleWFLevelMapViewModel();                    
        //            viewmodel.ddlData.shouldGetData = true;
        //            viewmodel.project_syscode = project_syscode;

        //            if (module_syscode == 0) //Load Projects
        //            {
        //                string predcName = nameof(viewmodel.project_syscode);
        //                object projSyscode = project_syscode;

        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ProjectMaster]["GetData"] = true;
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster]["GetData"] = true;
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster].Add(predcName, projSyscode);

        //                var response = client.PostAsJsonAsync(cWebApiNames.APIGetDDLData, viewmodel.ddlData).Result;
        //                var responseMsg = response.Content.ReadAsStringAsync().Result;
        //                if (response.IsSuccessStatusCode)
        //                {
        //                    viewmodel.ddlData = JsonConvert.DeserializeObject<DDLDTO>(responseMsg);
        //                    viewmodel.lstLevelTaskUsers = null;
        //                    if (viewmodel.ddlData.opStatus)
        //                    {
        //                        viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", projSyscode);
        //                        viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", 0);
        //                    }
        //                }
        //                else
        //                    throw new Exception(response.ReasonPhrase);
        //            }
        //            else //Load Modules DD
        //            {
        //                string predcName = nameof(viewmodel.project_syscode);

        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ProjectMaster]["GetData"] = true;
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster]["GetData"] = true;
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master]["GetData"] = true;
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster].Add(predcName, project_syscode);

        //                predcName = nameof(vw_employee_master.department_name);
        //                var PredcValue = "Information Technology";
        //                viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master].Add(predcName, PredcValue);

        //                var response = client.PostAsJsonAsync(cWebApiNames.GetLevelTaskUsersList, viewmodel).Result;
        //                var responseMsg = response.Content.ReadAsStringAsync().Result;
        //                if (response.IsSuccessStatusCode)
        //                {
        //                    viewmodel = JsonConvert.DeserializeObject<ModuleWFLevelMapViewModel>(responseMsg);
        //                    viewmodel.project_syscode = project_syscode;
        //                    viewmodel.module_syscode = module_syscode;
        //                    if (viewmodel.opStatus)
        //                    {
        //                        viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", project_syscode);
        //                        viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", module_syscode);
        //                        //viewmodel.SLEmployee = new MultiSelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.vw_employee_master), "Value", "Text");
        //                    }
        //                }
        //                else
        //                    throw new Exception(response.ReasonPhrase);
        //            }
        //        }
        //        else
        //        {
        //            return RedirectToAction("Logout", "Login", new { Area = "" });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.ErrorMessage = ex.Message;
        //        TempData["ErrorMessage"] = ex.Message;
        //        ModelState.AddModelError("KeyException", ex.Message);
        //        Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "GetModules", "ModuleWFLevelMapController");
        //    }
        //    return View("ModuleWFLevelMap", viewmodel);
        //}

        //[HttpPost]
        //// [SubmitButtonSelector(Name = "action", Argument = "Save")]
        //public ActionResult Save(ModuleWFLevelMapViewModel viewmodel)
        //{
        //    try
        //    {
        //        if (this.Session["emp_syscode"] != null)
        //        {
        //            if (viewmodel == null)
        //                throw new ArgumentNullException("viewmodel", "Model cannot be null.");

        //            int Project_Syscode = viewmodel.project_syscode;
        //            int moduleSyscode = viewmodel.module_syscode;
        //            /**/
        //            //string predcName = nameof(viewmodel.project_syscode);

        //            //viewmodel.created_by = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
        //            //viewmodel.ddlData.shouldGetData = true;
        //            //viewmodel.ddlData.Predicate[DBTableNameEnums.ProjectMaster]["GetData"] = true;
        //            //viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster]["GetData"] = true;
        //            //viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master]["GetData"] = true;
        //            //viewmodel.ddlData.Predicate[DBTableNameEnums.ModuleMaster].Add(predcName, Project_Syscode);

        //            //predcName = nameof(vw_employee_master.department_name);
        //            //var PredcValue = "Information Technology";
        //            //viewmodel.ddlData.Predicate[DBTableNameEnums.vw_employee_master].Add(predcName, PredcValue);
        //            /**/
        //            var response = client.PostAsJsonAsync(cWebApiNames.APIAddWFLevelMapping, viewmodel).Result;
        //            var responseMsg = response.Content.ReadAsStringAsync().Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                viewmodel = JsonConvert.DeserializeObject<ModuleWFLevelMapViewModel>(responseMsg);
        //                if (viewmodel.opStatus)
        //                {
        //                    viewmodel.project_syscode = Project_Syscode;
        //                    viewmodel.module_syscode = moduleSyscode;
        //                    //viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", Project_Syscode);
        //                    //viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", moduleSyscode);
        //                    //viewmodel.SLEmployee = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.vw_employee_master), "Value", "Text", 0);

        //                    //Response.Clear();

        //                    return Index(viewmodel, "");
        //                    //return RedirectToAction("Index", "ModuleWFLevelMap", new { Area="Master", viewmodel = viewmodel });
        //                    //return View("ModuleWFLevelMap",viewmodel);
        //                }
        //            }
        //            else
        //                throw new Exception(response.ReasonPhrase);
        //        }
        //        else
        //        {
        //            return RedirectToAction("Logout", "Login", new { Area = "" });
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.ErrorMessage = ex.Message;
        //        TempData["ErrorMessage"] = ex.Message;
        //        ModelState.AddModelError("KeyException", ex.Message);
        //        Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "Index", "ModuleWFLevelMapController");
        //    }
        //    return View(viewmodel);
        //}




        //[HttpPost]
        //public ActionResult GetModulesByProject(ModuleWFLevelMapViewModel viewmodel)
        //{

        //    string ModulesListJson = string.Empty;
        //    try
        //    {
        //        if (this.Session["emp_syscode"] != null)
        //        {
        //            int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
        //            int proj_syscode = viewmodel.project_syscode;

        //            if (proj_syscode == 0)
        //            {
        //                throw new Exception("Invalid Project.");
        //            }

        //            // projmodel = new ProjectViewModel();
        //            if (viewmodel.module_syscode == 0) //Load Projects
        //            {
        //                viewmodel.project_syscode = proj_syscode;
        //                viewmodel.ddlData.shouldGetData = true;

        //                var response = client.PostAsJsonAsync(cWebApiNames.APIGetModulesListByProject, viewmodel).Result;
        //                var responseMsg = response.Content.ReadAsStringAsync().Result;
        //                if (response.IsSuccessStatusCode)
        //                {
        //                    viewmodel = JsonConvert.DeserializeObject<ModuleWFLevelMapViewModel>(responseMsg);
        //                    if (viewmodel.opStatus)
        //                    {
        //                        viewmodel.SLProjects = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ProjectMaster), "Value", "Text", 0);
        //                        viewmodel.SLModules = new SelectList(viewmodel.ddlData.Data.ExtractDDLDataForKey(DBTableNameEnums.ModuleMaster), "Value", "Text", 0);

        //                    }
        //                }
        //                else
        //                {
        //                    throw new Exception(response.ReasonPhrase);
        //                } 
        //            }
        //            else //Load Modules DD
        //            {
        //                if (viewmodel.opStatus)
        //                {
        //                    LevelTaskUserDTO ltu = new LevelTaskUserDTO();
        //                    ltu.level_name = "Level1";
        //                    ltu.level_syscode = 1;
        //                    ltu.users = "Aarti";
        //                    ltu.weightage = 75;

        //                    LevelTaskUserDTO ltu1 = new LevelTaskUserDTO();
        //                    ltu1.level_name = "Level2";
        //                    ltu1.level_syscode = 2;
        //                    ltu1.users = "Divya";
        //                    ltu1.weightage = 25;

        //                    List<LevelTaskUserDTO> lst = new List<LevelTaskUserDTO>();
        //                    lst.Add(ltu);
        //                    lst.Add(ltu1);

        //                    viewmodel.lstLevelTaskUsers = lst;
        //                }
        //            }

        //        }
        //        else
        //            return RedirectToAction("Logout", "Login", new { Area = "" });

        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.ErrorMessage = ex.Message;
        //        TempData["ErrorMessage"] = ex.Message;
        //        ModelState.AddModelError("KeyException", ex.Message);
        //        Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "GetModules", "ModuleWFLevelMapController");
        //    }
        //    return View("ModuleWFLevelMap", viewmodel);
        //}
        //[HttpPost]
        //public JsonResult GetModulesByProject(string id)
        //{
        //    ProjectViewModel projmodel = null;
        //    string ModulesListJson = string.Empty;
        //    try
        //    {
        //        if (this.Session["emp_syscode"] != null)
        //        {

        //            int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
        //            int proj_syscode = String.IsNullOrEmpty(id) ? 0 : Convert.ToInt32(id); //ComLibCommon.Base64Decode(id)

        //            if (proj_syscode == 0)
        //            {
        //                throw new Exception("Invalid Project.");
        //            }

        //            projmodel = new ProjectViewModel();
        //            projmodel.project_syscode = proj_syscode;
        //            projmodel.ddlData.shouldGetData = true;

        //            var response = client.PostAsJsonAsync(cWebApiNames.APIGetProjectByID, projmodel).Result;
        //            var responseMsg = response.Content.ReadAsStringAsync().Result;
        //            if (response.IsSuccessStatusCode)
        //            {
        //                projmodel = JsonConvert.DeserializeObject<ProjectViewModel>(responseMsg);
        //                if (projmodel.opStatus)
        //                {
        //                    ModulesListJson = JsonConvert.SerializeObject(projmodel.lstModules);
        //                }
        //            }
        //            else
        //            {
        //                throw new Exception(response.ReasonPhrase);
        //            }
        //            return Json(ModulesListJson, JsonRequestBehavior.AllowGet);
        //        }
        //        else
        //            return Json("SessionExpired", JsonRequestBehavior.AllowGet);

        //    }
        //    catch (Exception ex)
        //    {
        //        ModelState.AddModelError("KeyException", ex.Message);
        //        Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "GetModulesByProject", "ModuleWFLevelMapController");
        //        return Json(ex.Message, JsonRequestBehavior.AllowGet);
        //    }
        //}
        //public ActionResult GetWFLevels(string id)
        //{
        //    ModuleWFLevelMapViewModel viewmodel = null;

        //    try
        //    {
        //        if (this.Session["emp_syscode"] != null)
        //        {

        //            int loggedin_user = Convert.ToInt32(Convert.ToString(this.Session["emp_syscode"]));
        //            int module_syscode = String.IsNullOrEmpty(id) ? 0 : Convert.ToInt32(ComLibCommon.Base64Decode(id)); //ComLibCommon.Base64Decode(id)

        //            if (module_syscode == 0)
        //            {
        //                throw new Exception("Invalid Module.");
        //            }
        //            viewmodel = new ModuleWFLevelMapViewModel();
        //            viewmodel.opStatus = true;

        //            //var response = client.PostAsJsonAsync(cWebApiNames.APIGetProjectByID, projmodel).Result;
        //            //var responseMsg = response.Content.ReadAsStringAsync().Result;
        //            //if (response.IsSuccessStatusCode)
        //            //{
        //            //projmodel = JsonConvert.DeserializeObject<ProjectViewModel>(responseMsg);
        //            if (viewmodel.opStatus)
        //            {
        //                LevelTaskUserViewModel ltu = new LevelTaskUserViewModel();
        //                ltu.level_name = "Level1";
        //                ltu.level_syscode = 1;
        //                ltu.users = "Aarti";
        //                ltu.weightage = 75;

        //                LevelTaskUserViewModel ltu1 = new LevelTaskUserViewModel();
        //                ltu1.level_name = "Level2";
        //                ltu1.level_syscode = 2;
        //                ltu1.users = "Divya";
        //                ltu1.weightage = 25;

        //                List<LevelTaskUserViewModel> lst = new List<LevelTaskUserViewModel>();
        //                lst.Add(ltu);
        //                lst.Add(ltu1);

        //                viewmodel.lstLevelTaskUserViewModel = lst;
        //            }
        //            //}
        //            //else
        //            //{
        //            //    throw new Exception(response.ReasonPhrase);
        //            //}


        //        }
        //        else
        //            return RedirectToAction("Logout", "Login", new { Area = "" });

        //    }
        //    catch (Exception ex)
        //    {
        //        ViewBag.ErrorMessage = ex.Message;
        //        TempData["ErrorMessage"] = ex.Message;
        //        ModelState.AddModelError("KeyException", ex.Message);
        //        Log.LogError(ex.Message, Convert.ToString(this.Session["employee_name"]), Convert.ToString(this.Session["employee_syscode"]), "GetModules", "ModuleWFLevelMapController");
        //    }
        //    return View("ModuleWFLevelMap", viewmodel);

        //}

        #endregion
    }
}