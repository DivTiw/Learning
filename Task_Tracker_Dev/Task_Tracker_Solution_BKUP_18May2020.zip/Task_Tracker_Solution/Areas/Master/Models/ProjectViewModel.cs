﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;

namespace Task_Tracker_Solution.Areas.Master.Models
{
    public class ProjectViewModel : ProjectDM
    {
        public string ModulesListJson { get; set; }
        public string WorkflowListJson { get; set; }
        //public List<ModuleViewModel> lstModuleVM { get; set; }
        public List<SelectItemDTO> SLWorkFlow { get; set; }
    }
}