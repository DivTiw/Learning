﻿using System.Web.Mvc;
using Task_Tracker_CommonLibrary.Entity;

namespace Task_Tracker_Solution.Areas.Master.Models
{
    public class ModuleViewModel : ModuleMaster
    {
        public SelectList slWorkflowList { get; set; }
    }
}