﻿using System;
using System.Configuration;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Mvc;

namespace Task_Tracker_Solution.Areas.Common.Controllers
{
    public class TaskTrackerBaseController : Controller
    {
        protected readonly HttpClient client = null;

        public TaskTrackerBaseController()
        {
            string web_apiAddress = ConfigurationManager.AppSettings["web_apiAddress"].ToString();

            client = new HttpClient();
            client.BaseAddress = new Uri(web_apiAddress);
            //client.Timeout = System.TimeSpan.FromMilliseconds(Convert.ToInt32(ConfigurationManager.AppSettings["ClientTimeout"]));
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }
    }
}