﻿//using Common_Components;
using Common_Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_Library.Interface;
using Task_Tracker_Library.Repository;
using Task_Tracker_CommonLibrary.Utility;
using Task_tracker_WebAPI.Controllers;

namespace Task_tracker_WebAPI.Areas.Master.Controllers
{
    public class ProjectController : BaseAPIController
    {

        [HttpPost]

        public IList<ProjectMaster> GetAllProjectList()
        {
            IList<ProjectMaster> mList = null;
            //ICommonRepository<ProjectMaster> ProjRepo = new ProjectRepository<ProjectMaster>(new TTDBContext());//CommonRepository<ProjectMaster>();
            try
            {
                mList = new List<ProjectMaster>();
                using (var uow = new UnitOfWork())
                {
                    mList = uow.ProjectsRepo.GetList(x => x.is_deleted == false).ToList();
                }
            }
            catch (Exception ex)
            {
                Exception e = ex.ReturnActualException();                
                Log.LogError(e.Message, "", null, "GetAllProjectList", "ProjectController");
            }


            return mList;
        }

        [HttpPost]
        public OperationDetailsDTO PostProject([FromBody] ProjectMaster projMaster)
        {
            OperationDetailsDTO od = new OperationDetailsDTO();
            if (string.IsNullOrEmpty(projMaster.project_name))
            {
                od.opStatus = false;
                od.opMsg = "Invalid Project";
            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    uow.ProjectsRepo.Add(projMaster);//.saveOperation(projMaster, System.Data.Entity.EntityState.Added);
                    uow.commitTT();
                    projMaster.opStatus = true;
                    projMaster.opMsg = "Project created successfully!";
                    return projMaster;
                }
            }
            catch (Exception ex)
            {
                Exception e = ex.ReturnActualException();
                string exMsg = e.Message;             
                Log.LogError(exMsg, "", projMaster.created_by.ToString(), "PostProject", "ProjectController");
                od.opStatus = false;
                od.opMsg = "Exception Occurred! Exception: "+ exMsg;                
                od.opInnerException = e;
            }
            return od;
        }

        [HttpPost]
        public OperationDetailsDTO GetProjectByID([FromBody] ProjectDM project)
        {
            OperationDetailsDTO od = new OperationDetailsDTO();
            ProjectDM wf = project;

            if (project.project_syscode <= 0) throw new Exception("Invalid project reference, Please make sure selected project is valid.");

            //ICommonRepository<ProjectMaster> ComRepo = new ProjectRepository<ProjectMaster>(new TTDBContext()); //new CommonRepository<ProjectMaster>();

            try
            {
                using (var uow = new UnitOfWork())
                {
                    var projModel = uow.ProjectsRepo.GetList(x => x.is_deleted == false && x.project_syscode.Equals(project.project_syscode), x => x.lstModules)?.FirstOrDefault();

                    if (projModel == null)
                        throw new Exception("Some Error occured while fetching project data.");

                    projModel.lstModules = projModel.lstModules.Where(x => x.is_deleted == false).ToList();

                    wf = projModel.Map<ProjectMaster, ProjectDM>();

                    if (wf == null) throw new Exception("Some error occured while mapping ProjectMaster to ProjectDM");

                    //if (project.ddlData.shouldGetData)
                    wf.ddlData = project.ddlData; //Again replacing with original ddlData object as it was replaced by the auto mapper while mapping from the entity to domain model.
                    uow.CommonRepo.fillDDLdata(wf.ddlData);  //wf.ddlData.fillDDLdata(ComRepo.fillDDLdata);

                    wf.opStatus = true;
                }

            }
            catch (Exception ex)
            {
                Exception e = ex.ReturnActualException();

                Log.LogError(e.Message, "", null, "GetProjectByID", "ProjectController");
                od.opStatus = false;
                od.opMsg = e.Message;
                od.opInnerException = e;
            }

            return wf;
        }
        [HttpPut]
        public OperationDetailsDTO PutProject([FromBody] ProjectMaster proj)
        {
            OperationDetailsDTO od = new OperationDetailsDTO();
            if (proj == null || proj.project_syscode == 0)
            {
                od.opStatus = false;
                od.opMsg = "Invalid Project";
            }
            try
            {
                
                using (var uow = new UnitOfWork())
                {
                    uow.ProjectsRepo.Update(proj);//saveOperation(proj, System.Data.Entity.EntityState.Modified);
                    uow.commitTT();
                    od.opStatus = true;
                    od.opMsg = "Project updated successfully!";
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", proj.created_by.ToString(), "PutProject", "ProjectController");
                od.opStatus = false;
                od.opMsg = ex.Message;
                od.opInnerException = ex;
            }
            return od;
        }


        [HttpDelete]
        public OperationDetailsDTO DeleteProject([FromBody] ProjectMaster proj)
        {
            OperationDetailsDTO od = new OperationDetailsDTO();
            if (proj == null || proj.project_syscode == 0)
            {
                od.opStatus = false;
                od.opMsg = "Invalid Project";
            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    uow.ProjectsRepo.Update(proj);//saveOperation(proj, System.Data.Entity.EntityState.Deleted); 
                    uow.commitTT();
                    od.opStatus = true;
                    od.opMsg = "Successfully deleted the project.";
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", proj.created_by.ToString(), "DeleteProject", "ProjectController");
                od.opStatus = false;
                od.opMsg = ex.Message;
                od.opInnerException = ex;
            }
            return od;
        }
    }
}
