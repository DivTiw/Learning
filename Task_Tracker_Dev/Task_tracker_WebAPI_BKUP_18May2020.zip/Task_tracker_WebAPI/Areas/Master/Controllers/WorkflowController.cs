﻿using Common_Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_Library.Interface;
using Task_Tracker_Library.Repository;
using Task_tracker_WebAPI.Controllers;

namespace Task_tracker_WebAPI.Areas.Master.Controllers
{
    public class WorkflowController : BaseAPIController
    {
        [HttpPost]
        public IList<WorkflowMaster> GetAllWorkFlowList([FromBody] WorkflowMaster workflow)
        {
            IList<WorkflowMaster> mList = null;
            //ICommonRepository<WorkflowMaster> ComRepo = new MasterRepository<WorkflowMaster>(new TTDBContext());//new CommonRepository<WorkflowMaster>();
            try
            {
                mList = new List<WorkflowMaster>();
                using (var uow = new UnitOfWork())
                {
                    mList = uow.WorkflowRepo.GetList(x => x.is_deleted == false).ToList(); // && x.workflow_syscode.Equals(workflowID) , x => x.lstModules 
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", null, "GetAllWorkFlowList", "WorkflowController");
            }


            return mList;
        }

        [HttpPost]
        public WorkflowMaster GetWorkFlowByID([FromBody] WorkflowMaster workflow)
        {
            WorkflowMaster wf = null;
            //ICommonRepository<WorkflowMaster> ComRepo = new MasterRepository<WorkflowMaster>(new TTDBContext()); //new CommonRepository<WorkflowMaster>();
            try
            {
                wf = new WorkflowMaster();
                using (var uow = new UnitOfWork())
                {
                    wf = uow.WorkflowRepo.GetList(x => x.is_deleted == false && x.workflow_syscode.Equals(workflow.workflow_syscode), x => x.lstWFLevels)?.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", null, "GetWorkFlowByID", "WorkflowController");
            }

            return wf;
        }

        [HttpPost]
        public WorkflowMaster PostWorkflow([FromBody] WorkflowMaster workflow)
        {

            if (string.IsNullOrEmpty(workflow.workflow_name))
            {
                workflow = new WorkflowMaster();
                workflow.opStatus = false;
                workflow.opMsg = "Invalid workflow";
            }
            try
            {
                OperationDetailsDTO od = new OperationDetailsDTO(); ;
                using (var uow = new UnitOfWork())
                {
                    uow.WorkflowRepo.Add(workflow);//saveOperation(workflow, System.Data.Entity.EntityState.Added); 
                    uow.commitTT();
                    od.opStatus = true;
                }
                if (od.opStatus)
                {
                    workflow.opStatus = true;
                    workflow.opMsg = od.opMsg;
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", workflow.created_by.ToString(), "PostWorkflow", "WorkflowController");
                workflow.opStatus = false;
                workflow.opMsg = "Exception Occurred!";
                workflow.opInnerException = ex;
            }
            return workflow;
        }


        [HttpPut]
        public WorkflowMaster PutWorkflow([FromBody] WorkflowMaster workflow)
        {
            if (workflow.workflow_syscode == 0)
            {
                workflow = new WorkflowMaster();
                workflow.opStatus = false;
                workflow.opMsg = "Invalid workflow";
                return workflow;
            }
            try
            {
                OperationDetailsDTO od = new OperationDetailsDTO();
                using (var uow = new UnitOfWork())
                {
                    uow.WorkflowRepo.Update(workflow);//saveOperation(workflow, System.Data.Entity.EntityState.Modified);
                    uow.commitTT();
                    od.opStatus = true;
                }

                if (od.opStatus)
                {
                    workflow.opStatus = true;
                    workflow.opMsg = "Record updated successfully.";
                }

            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", workflow.created_by.ToString(), "PutWorkflow", "WorkflowController");
                workflow.opStatus = false;
                workflow.opMsg = ex.Message;//"Exception Occurred!";
                workflow.opInnerException = ex;
            }
            return workflow;
        }


        [HttpDelete]
        public WorkflowMaster DeleteWorkflow([FromBody] WorkflowMaster workflow)
        {

            if (workflow.workflow_syscode == 0)
            {
                workflow = new WorkflowMaster();
                workflow.opStatus = false;
                workflow.opMsg = "Invalid workflow";
            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    uow.WorkflowRepo.Update(workflow);//saveOperation(workflow, System.Data.Entity.EntityState.Deleted); 
                    uow.commitTT();
                    workflow.opStatus = true;
                    workflow.opMsg = "Successfully deleted the record.";
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", workflow.created_by.ToString(), "PutWorkflow", "WorkflowController");
                workflow.opStatus = false;
                workflow.opMsg = ex.Message;
                workflow.opInnerException = ex;
            }
            return workflow;
        }


        [HttpPost]
        public WorkflowMaster AddUpdateWorkflowLevels([FromBody] IList<WorkflowLevelDetails> workflowLevels)
        {
            WorkflowMaster objWorkflow = new WorkflowMaster();

            if (workflowLevels.Count == 0)
            {
                objWorkflow.opStatus = false;
                objWorkflow.opMsg = "Invalid workflow";
                return objWorkflow;
            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    //OperationDetailsDTO od = new OperationDetailsDTO();

                    foreach (var level in workflowLevels)
                    {
                        //System.Data.Entity.EntityState operation;
                        if (level.level_syscode > 0)
                            uow.WorkflowLevelRepo.Update(level);
                        //operation = System.Data.Entity.EntityState.Modified;
                        else
                            uow.WorkflowLevelRepo.Add(level);
                        //operation = System.Data.Entity.EntityState.Added;

                        //od = uow.WorkflowLevelRepo.saveOperation(level, operation);                        
                    }

                    uow.commitTT();
                    //od.opStatus = true;
                    objWorkflow.opStatus = true;
                    objWorkflow.lstWFLevels = workflowLevels; //since this entity object is directly tracked by the context, its primary key gets updated.
                    //if (od.opStatus)
                    //{
                    //    level.opStatus = true;
                    //    if (objWorkflow.lstWFLevels == null)
                    //        objWorkflow.lstWFLevels = new List<WorkflowLevelDetails>();

                    //    objWorkflow.lstWFLevels.Add(level);
                    //    objWorkflow.opStatus = true;
                    //    objWorkflow.opMsg = od.opMsg;
                    //}
                    //else throw new Exception(od.opMsg);
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", "", "AddUpdateWorkflowLevels", "WorkflowController");
                objWorkflow.opStatus = false;
                objWorkflow.opMsg = ex.Message;
            }
            return objWorkflow;
        }


    }
}
