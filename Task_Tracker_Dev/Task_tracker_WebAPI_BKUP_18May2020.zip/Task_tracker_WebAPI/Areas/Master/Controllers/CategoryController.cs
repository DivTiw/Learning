﻿using Common_Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_CommonLibrary.Others;
using Task_Tracker_CommonLibrary.Utility;
using Task_Tracker_Library.Repository;
using Task_tracker_WebAPI.Controllers;

namespace Task_tracker_WebAPI.Areas.Master.Controllers
{
    public class CategoryController : BaseAPIController
    {
        [HttpPost]
        public IList<TaskCategoryMaster> GetAllCategoryList([FromBody] TaskCategoryMaster category)
        {
            IList<TaskCategoryMaster> mList = null;
            //ICommonRepository<WorkflowMaster> ComRepo = new MasterRepository<WorkflowMaster>(new TTDBContext());//new CommonRepository<WorkflowMaster>();
            try
            {
                mList = new List<TaskCategoryMaster>();
                using (var uow = new UnitOfWork())
                {
                    mList = uow.TaskCategoryRepo.GetList(x => !x.is_deleted, x=> x.vw_Dept).ToList(); // && x.workflow_syscode.Equals(workflowID) , x => x.lstModules 
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", null, "GetAllCategoryList", "CategoryController");
            }


            return mList;
        }

        [HttpPost]
        public CategoryDM GetCategoryByID([FromBody] TaskCategoryMaster category)
        {
            CategoryDM tcm = null;
            //ICommonRepository<WorkflowMaster> ComRepo = new MasterRepository<WorkflowMaster>(new TTDBContext()); //new CommonRepository<WorkflowMaster>();
            try
            {
                tcm = new CategoryDM();
                using (var uow = new UnitOfWork())
                {
                    tcm = uow.TaskCategoryRepo.GetList(x=> x.category_syscode == category.category_syscode).Select(x=> new CategoryDM { category_name = x.category_name}).FirstOrDefault();//uow.TaskCategoryRepo.GetList(x => x.is_deleted == false && x.category_syscode.Equals(category.category_syscode), x => x.lstWFLevels)?.FirstOrDefault();
                    //tcm = cat.Map<TaskCategoryMaster, CategoryDM>();
                    tcm.ddlData.Predicate[DBTableNameEnums.vw_department_master]["GetData"] = true;
                    uow.CommonRepo.fillDDLdata(tcm.ddlData);
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", null, "GetCategoryByID", "CategoryController");
            }

            return tcm;
        }

        [HttpPost]
        public TaskCategoryMaster PostCategory([FromBody] TaskCategoryMaster Category)
        {

            if (string.IsNullOrEmpty(Category.category_name))
            {
                Category = new TaskCategoryMaster();
                Category.opStatus = false;
                Category.opMsg = "Invalid workflow";
            }
            try
            {
                OperationDetailsDTO od = new OperationDetailsDTO(); ;
                using (var uow = new UnitOfWork())
                {
                    uow.TaskCategoryRepo.Add(Category);//saveOperation(Category, System.Data.Entity.EntityState.Added); 
                    uow.commitTT();
                    od.opStatus = true;
                }
                if (od.opStatus)
                {
                    Category.opStatus = true;
                    Category.opMsg = od.opMsg;
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", Category.created_by.ToString(), "PostCategory", "CategoryController");
                Category.opStatus = false;
                Category.opMsg = "Exception Occurred!";
                Category.opInnerException = ex;
            }
            return Category;
        }


        [HttpPut]
        public TaskCategoryMaster PutCategory([FromBody] TaskCategoryMaster Category)
        {
            if (Category.category_syscode == 0)
            {
                Category = new TaskCategoryMaster();
                Category.opStatus = false;
                Category.opMsg = "Invalid Category";
                return Category;
            }
            try
            {
                OperationDetailsDTO od = new OperationDetailsDTO();
                using (var uow = new UnitOfWork())
                {
                    uow.TaskCategoryRepo.Update(Category);//saveOperation(Category, System.Data.Entity.EntityState.Modified);
                    uow.commitTT();
                    od.opStatus = true;
                }

                if (od.opStatus)
                {
                    Category.opStatus = true;
                    Category.opMsg = "Record updated successfully.";
                }

            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", Category.created_by.ToString(), "PutCategory", "CategoryController");
                Category.opStatus = false;
                Category.opMsg = ex.Message;//"Exception Occurred!";
                Category.opInnerException = ex;
            }
            return Category;
        }

    }
}
