﻿using Common_Components;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_Library.Interface;
using Task_Tracker_Library.Repository;
using Task_tracker_WebAPI.Controllers;

namespace Task_tracker_WebAPI.Areas.Master.Controllers
{
    public class ModuleController : BaseAPIController
    {
        [HttpPost]
        public ProjectMaster AddUpdateProjectModules([FromBody] IList<ModuleMaster> modules)
        {
            ProjectMaster pm = new ProjectMaster();

            if (modules.Count == 0)
            {
                pm.opStatus = false;
                pm.opMsg = "Invalid Project";
            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    foreach (var module in modules)
                    {
                        OperationDetailsDTO od = new OperationDetailsDTO();

                        //System.Data.Entity.EntityState operation;
                        if (module.module_syscode > 0)
                            uow.ModuleRepo.Update(module);
                        //operation = System.Data.Entity.EntityState.Modified;
                        else
                            uow.ModuleRepo.Add(module);
                        //operation = System.Data.Entity.EntityState.Added;

                        //od = uow.ModuleRepo.saveOperation(module, operation);                                             
                    }
                    uow.commitTT();
                    pm.lstModules = modules;
                    pm.opStatus = true;
                    pm.opMsg = "Modules added successfully. ";
                    //if (od.opStatus)
                    //{
                    //    module.opStatus = true;
                    //    if (pm.lstModules == null)
                    //        pm.lstModules = new List<ModuleMaster>();

                    //pm.lstModules.Add(module);
                    //pm.opStatus = true;
                    //    pm.opMsg = od.opMsg;
                    //}
                    //else throw new Exception(od.opMsg);
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", "", "ProjectModules", "ProjectController");
                pm.opStatus = false;
                pm.opMsg = ex.Message;
            }
            return pm;
        }

        [HttpPost]
        public ModuleMaster PostModule([FromBody] ModuleMaster modMaster)
        {
            string returnvalue = string.Empty;

            if (modMaster == null)
            {
                modMaster = new ModuleMaster();
                modMaster.opStatus = false;
                modMaster.opMsg = "Invalid Module";

            }
            try
            {
                using (var uow = new UnitOfWork())
                {
                    uow.ModuleRepo.Add(modMaster);//saveOperation(modMaster, System.Data.Entity.EntityState.Added); 
                    uow.commitTT();
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", modMaster.created_by.ToString(), "PostModule", "ModuleController");
                modMaster.opStatus = false;
                modMaster.opMsg = ex.Message;
                modMaster.opInnerException = ex;
            }
            return modMaster;
        }
        

        [HttpPost]
        public WorkflowMaster GetModuleWorkflow(ModuleMaster mm)
        {
            WorkflowMaster wlf = null;
            //ICommonRepository<WorkflowMaster> ComRepo = new MasterRepository<WorkflowMaster>(new TTDBContext());
            try
            {
                using (var uow = new UnitOfWork())
                {
                    wlf = uow.WorkflowRepo.GetList(x => x.workflow_syscode.Equals(mm.workflow_syscode) && x.is_active && x.is_deleted == false, x => x.lstWFLevels)?.FirstOrDefault();
                }
            }
            catch (Exception ex)
            {
                Log.LogError(ex.Message, "", null, "GetProjectModulesList", "ModuleController");
            }
            return wlf;
        }
    }
}
