﻿using Common_Components;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web;
using Task_Tracker_CommonLibrary.DomainModels;
using Task_Tracker_CommonLibrary.Entity;
using Task_Tracker_Library.Repository;
using Task_Tracker_Library.Repository.Services;

namespace Task_tracker_WebAPI.Areas.Services.Controllers
{
    public class FileService
    {
        HttpClient fsWebClient;
        public FileService(HttpClient _client)
        {
            fsWebClient = _client;
        }
        public OperationDetailsDTO UploadFiles(HttpPostedFile file, string attachType, int attachSyscode, int userId)
        {
            OperationDetailsDTO od = new OperationDetailsDTO();
            try
            {
                using (var uow = new UnitOfWork())
                {
                    string fileName = file.FileName;
                    string fileType = Path.GetExtension(fileName);
                    string displayName = fileName.Replace("."+fileType, "");
                    TaskAttachment ta = new TaskAttachment {
                        attachment_filename = fileName
                                                            , attachment_display_name = displayName
                                                            , attachment_identifier = Guid.NewGuid()
                                                            , created_by = userId
                                                            , type_detail = attachType
                                                            , type_syscode = attachSyscode
                                                            , created_on = DateTime.Now
                                                            , is_deleted = false                                                            
                                                            };
                    uow.FileServiceRepo.Add(ta);
                    uow.commitTT();

                    if (ta.attachment_syscode > 0)
                    {
                        var response = new HttpResponseMessage();

                        string strAttachmentGuid = ta.attachment_identifier.ToString();
                        TokenModel tm = new TokenModel();
                        tm.CreatedBy = ta.created_by;
                        tm.AttachmentGUID = strAttachmentGuid;
                        tm.RecordSyscode = ta.attachment_syscode;
                        tm.UserRole = "User";
                        tm.EmployeeSyscode = ta.created_by;
                        string token = uow.FileServiceRepo.GetToken(tm);

                        #region Testing the token
                        string decToken = uow.FileServiceRepo.DecodeToken(token);
                        var values = JsonConvert.DeserializeObject<Dictionary<string, object>>(uow.FileServiceRepo.Decode(token));
                        Log.LogDebug($"{Environment.NewLine}Token is: {token} {Environment.NewLine} Decoded token:  {decToken} {Environment.NewLine} JSON value:  {values}", "", null, "UploadFiles", "FileService");
                        
                        #endregion
                        using (var content = new MultipartFormDataContent())
                        {
                            HttpPostedFile uploadFile = HttpContext.Current.Request.Files[0];
                            var streamContent = new StreamContent(uploadFile.InputStream);
                            streamContent.Headers.ContentType = MediaTypeHeaderValue.Parse(uploadFile.ContentType);
                            streamContent.Headers.ContentLength = uploadFile.ContentLength;
                            streamContent.Headers.ContentDisposition = new ContentDispositionHeaderValue("form-data")
                            {
                                Name = "fileToUpload",
                                FileName = uploadFile.FileName
                            };
                            content.Add(streamContent);

                            fsWebClient.DefaultRequestHeaders.Add("Token", token);
                            response = fsWebClient.PostAsync("api/Files/Upload", content).Result;

                            response.EnsureSuccessStatusCode();
                            if (response.IsSuccessStatusCode)
                            {
                                string responseString = response.Content.ReadAsStringAsync().Result;
                                if (!responseString.Contains(uploadFile.FileName))
                                {  
                                    //Delete file metadata and throw exception!                                  
                                    ta.is_deleted = true;
                                    uow.FileServiceRepo.Update(ta);
                                    uow.commitTT();
                                    throw new HttpException(responseString);
                                }
                                var settings = new JsonSerializerSettings
                                {
                                    NullValueHandling = NullValueHandling.Ignore,
                                    MissingMemberHandling = MissingMemberHandling.Ignore
                                };
                                var res = JsonConvert.DeserializeObject(responseString, settings);
                                string mongoFileId = ((Newtonsoft.Json.Linq.JContainer)res).First.Value<string>(uploadFile.FileName);

                                ta = uow.FileServiceRepo.Get(ta.attachment_syscode);
                                ta.mongo_file_id = mongoFileId;
                                uow.FileServiceRepo.Update(ta);
                                uow.commitTT();

                                od.opStatus = true;
                                od.opMsg = "File successfully uploaded!";
                            }
                            else
                            {
                                //Delete file metadata and throw exception!                                  
                                ta.is_deleted = true;
                                uow.FileServiceRepo.Update(ta);
                                uow.commitTT();
                                throw new HttpException(Convert.ToInt32(response.StatusCode), "Request to mongo API failed");
                            }
                        }
                    }
                    else
                    {
                        throw new HttpException("File Metadata upload failed!");
                    }
                }
            }
            catch (Exception ex)
            {
                string _ExceptionMSG = ex.Message;
                Log.LogError(_ExceptionMSG, "", null, "UploadFiles", "FileServiceController");
                od.opStatus = false;
                od.opMsg = "Some error occurred while uploading file, see opInnerexception for more details!";
                od.opInnerException = ex;
            }
            finally
            {
            }
            return od;
        }
    }
}