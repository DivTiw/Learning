﻿using System.Configuration;
using System.Net.Http;
using System.Web.Http;

namespace Task_tracker_WebAPI.Controllers
{
    public class BaseAPIController : ApiController
    {
        protected HttpClient webClient = null;
        protected string mongoBaseUri = ConfigurationManager.AppSettings["MongoFileServerBaseURL"].ToString();

        public BaseAPIController()
        {
            webClient = new HttpClient();
        }
    }
}
